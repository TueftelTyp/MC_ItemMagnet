package de.tuefteltyp.itemmagnet;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class ItemMagnet implements ModInitializer {
    public static final String ID = "itemmagnet";
    public static final Logger LOGGER = LoggerFactory.getLogger(ID);
    public static final Item WEAK = register("weak_magnet");
    public static final Item MID = register("mid_magnet");
    public static final Item STRONG = register("strong_magnet");

    private static Item register(String name) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath(ID, name));
        return Registry.register(BuiltInRegistries.ITEM, key, new Item(new Item.Properties().setId(key).stacksTo(1)));
    }
    @Override public void onInitialize() {
        MagnetConfig.load();
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(entries -> {
            entries.accept(WEAK); entries.accept(MID); entries.accept(STRONG);
        });
        ServerTickEvents.END_LEVEL_TICK.register(this::tick);
        LOGGER.info("ItemMagnet 1.0 initialized");
    }
    private void tick(ServerLevel level) {
        MagnetConfig cfg = MagnetConfig.INSTANCE;
        if (!cfg.enabled || level.getGameTime() % cfg.updateIntervalTicks != 0) return;
        for (ServerPlayer player : level.players()) {
            if (!player.isAlive() || player.isSpectator()) continue;
            double radius = Math.max(radius(player.getMainHandItem().getItem(), cfg), radius(player.getOffhandItem().getItem(), cfg));
            if (radius <= 0) continue;
            Vec3 target = player.position().add(0, .8, 0);
            AABB area = player.getBoundingBox().inflate(radius);
            for (ItemEntity drop : level.getEntitiesOfClass(ItemEntity.class, area, Entity::isAlive)) {
                if (drop.distanceToSqr(player) <= radius * radius) pull(drop, target, cfg);
            }
            if (cfg.attractExperience) {
                for (ExperienceOrb orb : level.getEntitiesOfClass(ExperienceOrb.class, area, Entity::isAlive)) {
                    if (orb.distanceToSqr(player) <= radius * radius) pull(orb, target, cfg);
                }
            }
        }
    }
    private static double radius(Item item, MagnetConfig cfg) {
        if (item == STRONG) return cfg.strongRadius;
        if (item == MID) return cfg.midRadius;
        if (item == WEAK) return cfg.weakRadius;
        return 0;
    }
    private static void pull(Entity entity, Vec3 target, MagnetConfig cfg) {
        Vec3 delta = target.subtract(entity.position());
        double distance = delta.length();
        if (distance < .15) return;
        Vec3 velocity = entity.getDeltaMovement().scale(.78).add(delta.scale(cfg.pullStrength / Math.max(1, distance)));
        if (velocity.lengthSqr() > cfg.maxSpeed * cfg.maxSpeed) velocity = velocity.normalize().scale(cfg.maxSpeed);
        entity.setDeltaMovement(velocity);
        entity.hurtMarked = true;
    }
}

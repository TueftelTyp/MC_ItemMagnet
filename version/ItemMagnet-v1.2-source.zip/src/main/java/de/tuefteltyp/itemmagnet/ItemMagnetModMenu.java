package de.tuefteltyp.itemmagnet;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.network.chat.Component;

public final class ItemMagnetModMenu implements ModMenuApi {
    @Override public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return parent -> {
            MagnetConfig c = MagnetConfig.INSTANCE;
            ConfigBuilder builder = ConfigBuilder.create().setParentScreen(parent).setTitle(Component.translatable("config.itemmagnet.title"));
            builder.setSavingRunnable(MagnetConfig::save);
            ConfigCategory cat = builder.getOrCreateCategory(Component.translatable("config.itemmagnet.general"));
            var e = builder.entryBuilder();
            cat.addEntry(e.startBooleanToggle(Component.translatable("config.itemmagnet.enabled"), c.enabled).setDefaultValue(true).setSaveConsumer(v -> c.enabled = v).build());
            cat.addEntry(e.startBooleanToggle(Component.translatable("config.itemmagnet.xp"), c.attractExperience).setDefaultValue(true).setSaveConsumer(v -> c.attractExperience = v).build());
            cat.addEntry(e.startDoubleField(Component.translatable("config.itemmagnet.weak"), c.weakRadius).setDefaultValue(6.0).setMin(0).setMax(64).setSaveConsumer(v -> c.weakRadius = v).build());
            cat.addEntry(e.startDoubleField(Component.translatable("config.itemmagnet.mid"), c.midRadius).setDefaultValue(12.0).setMin(0).setMax(64).setSaveConsumer(v -> c.midRadius = v).build());
            cat.addEntry(e.startDoubleField(Component.translatable("config.itemmagnet.strong"), c.strongRadius).setDefaultValue(20.0).setMin(0).setMax(64).setSaveConsumer(v -> c.strongRadius = v).build());
            cat.addEntry(e.startDoubleField(Component.translatable("config.itemmagnet.strength"), c.pullStrength).setDefaultValue(.23).setMin(.01).setMax(2).setSaveConsumer(v -> c.pullStrength = v).build());
            cat.addEntry(e.startDoubleField(Component.translatable("config.itemmagnet.speed"), c.maxSpeed).setDefaultValue(.9).setMin(.05).setMax(4).setSaveConsumer(v -> c.maxSpeed = v).build());
            cat.addEntry(e.startIntField(Component.translatable("config.itemmagnet.interval"), c.updateIntervalTicks).setDefaultValue(2).setMin(1).setMax(20).setSaveConsumer(v -> c.updateIntervalTicks = v).build());
            addRecipeCategory(builder, e, "weak", c.weakRecipe);
            addRecipeCategory(builder, e, "mid", c.midRecipe);
            addRecipeCategory(builder, e, "strong", c.strongRecipe);
            return builder.build();
        };
    }
    private static void addRecipeCategory(ConfigBuilder builder, ConfigEntryBuilder entries, String tier, String[][] grid) {
        ConfigCategory category = builder.getOrCreateCategory(Component.translatable("config.itemmagnet.recipe." + tier));
        for (int row = 0; row < 3; row++) {
            final int index = row;
            String original = String.join(", ", grid[row]);
            category.addEntry(entries.startStrField(
                Component.translatable("config.itemmagnet.recipe.row", row + 1), original)
                .setSaveConsumer(value -> grid[index] = RecipePackExporter.parseRow(value, grid[index]))
                .build());
        }
    }
}


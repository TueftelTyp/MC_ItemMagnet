package de.tuefteltyp.itemmagnet;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public final class MagnetConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("itemmagnet.json");
    public static MagnetConfig INSTANCE = new MagnetConfig();

    public boolean enabled = true;
    public boolean attractExperience = true;
    public double weakRadius = 6.0;
    public double midRadius = 12.0;
    public double strongRadius = 20.0;
    public double pullStrength = 0.23;
    public double maxSpeed = 0.9;
    public int updateIntervalTicks = 2;

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                MagnetConfig cfg = GSON.fromJson(Files.readString(FILE, StandardCharsets.UTF_8), MagnetConfig.class);
                if (cfg != null) INSTANCE = cfg;
            }
            save();
        } catch (Exception ex) {
            ItemMagnet.LOGGER.error("Could not load itemmagnet.json; using defaults", ex);
            INSTANCE = new MagnetConfig();
        }
    }
    public static void save() {
        try {
            INSTANCE.validate();
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(INSTANCE), StandardCharsets.UTF_8);
        } catch (Exception ex) {
            ItemMagnet.LOGGER.error("Could not save itemmagnet.json", ex);
        }
    }
    private void validate() {
        weakRadius = clamp(weakRadius, 0, 64);
        midRadius = clamp(midRadius, 0, 64);
        strongRadius = clamp(strongRadius, 0, 64);
        pullStrength = clamp(pullStrength, .01, 2);
        maxSpeed = clamp(maxSpeed, .05, 4);
        updateIntervalTicks = Math.max(1, Math.min(20, updateIntervalTicks));
    }
    private static double clamp(double x, double min, double max) {
        return Double.isFinite(x) ? Math.max(min, Math.min(max, x)) : min;
    }
}

# ItemMagnet v1.1

Minecraft 26.3 Fabric mod by TueftelTyp. Hold a magnet in either hand to pull in dropped items and, optionally, XP orbs. Three craftable upgrades are available.

| Magnet | Default radius | Crafting recipe |
| --- | --- | --- |
| Weak | 6 blocks | 4 iron ingots around 1 redstone |
| Mid | 12 blocks | 4 gold ingots around 1 weak magnet |
| Strong | 20 blocks | 4 diamonds around 1 mid magnet |

Configuration file: `config/itemmagnet.json`. The setting `attractExperience` enables/disables XP attraction. Mod Menu + Cloth Config provide the in-game GUI. Both are optional client-side dependencies; Fabric API is required. On a multiplayer server, server configuration controls behavior.

Build using **JDK 25**, **Gradle 9.6**: `gradle build`. The build produces `build/libs/itemmagnet-1.1.jar`. If desired create Gradle wrapper first: `gradle wrapper --gradle-version 9.6`. This archive does not include a wrapper and no compilation was performed in the authoring environment.

The three textures are temporary hand-drawn Minecraft-style pixel art. The requested 'Ausbaustufen F' was not present among A-E from the prior selection; the classic A-style three-tier progression was therefore used provisionally. Mod icon uses concept A.

## Configuration menu

Install Mod Menu and Cloth Config on the client to edit settings in-game. Without them, `config/itemmagnet.json` still works. For multiplayer, edit the server configuration to control attraction behavior.
